# Create a file

# Ask user their name, surname and favourite film - using input()

# Write these to a file

