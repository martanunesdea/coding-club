# Open file named "exam_results.txt"
# Extract data

# Group students into those who passed, and those who failed

# Print results OR 
# Write two files, one with those who passed, and one with those who

# Calculate % of students of passed

# hint 
aline.find('F') != -1 --> F